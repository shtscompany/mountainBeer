# Mountain Beer

This is "Mountain Beer", craft beer Site built with bootstrap and fontawesome.
It uses CDN's, in the footer is linked local address with google map, phone number, facebook and google icons.

## Technology
This site uses only HTML5, BOOTSTRAP 5 and fonteawesome


## Owner

This web site is made and registred by Shota Tsiklauri 

## Web Site link
[https://mountainbeer.ge](https://mountainbeer.ge)

## Hosting server

[https://proservice.ge](https://proservice.ge)

## Domen Registrator
[https://registrator.ge](https://registrator.ge)